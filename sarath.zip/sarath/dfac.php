<?php
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
$result = mysqli_query($con,"SELECT * FROM staff");
?>


<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" type="text/css" href="adminstyle.css">
    <link rel="stylesheet" type="text/css" href="deluplink.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
if (mysqli_num_rows($result) > 0) {
?>

<div class="topnav" id="myTopnav">
  <a href="admindashboard.php" >Dashboard</a>
  <a href="aaddfac.html">Add faculty</a>
  <a href="dfac.php">Edit Faculty</a>
  <a href="dtu.php">Delete Faculty</a>
  <a href="index.html">Logout</a>
 </div>
<table>
<div class="container">	
<tr>
<th>S.NO</th>
<th>STAFF ID</th>
<th>NAME</th>
<th>DEPARTMENT</th>
<th>PASSWORD</th>
<th>MOBILE NUMBER</th>
<th>OPERATION</th>
</tr>
<td><td><td>
</div>
			<?php
			$i=0;
			while($row = mysqli_fetch_array($result)) {
			?>
      
	  <tr>
       <td id="cen"><?php echo $row["id"]; ?></td>
	    <td id="cen"><?php echo $row["staffid"]; ?></td>
	    <td ><?php echo $row["name"]; ?></td>
		<td ><?php echo $row["dept"]; ?></td>
    <td><?php echo $row["spswd"]; ?></td>
    <td><?php echo $row["mobileno"]; ?>
		<td><a id="edit" href="updatefac.php?id=<?php echo $row["id"]; ?>">Edit</a></td>
      </tr>


			<?php
			$i++;
			}
			?>

 <?php
}
else
{
    echo "No result found";
}
?>
 </body>
</html>