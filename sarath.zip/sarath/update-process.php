<?php


$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}

if(count($_POST)>0) {
mysqli_query($con,"UPDATE student set id='" . $_POST['id'] . "', roll='" . $_POST['roll'] . "', name='" . $_POST['name'] . "', email='" . $_POST['email'] . "',dob='" . $_POST['dob'] . "',mobileno='" . $_POST['mobileno'] . "' ,sem='" . $_POST['sem'] . "',dept='" . $_POST['dept'] . "' WHERE id='" . $_POST['id'] . "'");
$message = "Record Modified Successfully";
}
$result = mysqli_query($con,"SELECT * FROM student WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>



<html>
<head>
<title>Update Employee Data</title>
<link rel="stylesheet" type="text/css" href="adminstyle.css">
<link rel="stylesheet" type="text/css" href="register.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>



<form  method="post" action="">
<div>

	<?php if(isset($message)) {
   echo "<h1>Record Modified Successfully!!</h1";

    } ?>
</div>
<div class="topnav" id="myTopnav">
    <a href="facdashboard.php" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="update.php">Edit Students</a>
   <a href="delstu.php">Delete Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 
</div>

  <div class="container">
    
    <hr>
    <label ><b>s.no</b></label>
    <input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
    <input type="number" name="id"  value="<?php echo $row['id']; ?>">

    <label ><b>Roll number</b></label>
   <input type="number" name="roll" class="txtField" value="<?php echo $row['roll']; ?>">

    <label ><b> Name</b></label>
    <input type="text" name="name" class="txtField" value="<?php echo $row['name']; ?>">
    
    <label ><b>Date of Birth</b></label>
    <input type="date" name="dob" class="txtField" value="<?php echo $row['dob']; ?>">

     <label ><b>Email</b></label>
    <input type="text" name="email" class="txtField" value="<?php echo $row['email']; ?>">

    <label ><b>Mobile number</b></label>
    <input type="number" name="mobileno" class="txtField" value="<?php echo $row['mobileno']; ?>">

    <label ><b>Semester</b></label>
    <input type="number" name="sem" class="txtField" value="<?php echo $row['sem']; ?>">

     <label ><b>Department</b></label>
    <input type="text" name="dept" class="txtField" value="<?php echo $row['dept']; ?>">


    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <input type="submit" name="submit" value="Submit" class="registerbtn">
  </div>
  </form>
</body>
</html>
  






