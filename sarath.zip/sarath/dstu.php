<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="adminstyle.css">
<title>Table with database</title>

<style>
	body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}



table {
border-collapse: collapse;
padding: 20%; 
width: 100%;
color: black;
font-size: 20px;
text-align: center;
background-color: #C0C0C0;
}

th {
padding-top: 2%;
color: black;
text-align: center;
font-size: 18px;
}
tr{
	font-size: 18px;

}


</style>
</head>
<body>


<div class="topnav" id="myTopnav">
  <a href="facdashboard.html" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="update.php">Edit Students</a>
   <a href="dtu.php">Delete Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 </div>

<table>
<div class="container">	
<tr>
<th>S.NO</th>
<th>ROLL NUMBER</th>
<th>NAME</th>
<th>EMAIL</th>
<th>DATE OF BIRTH</th>
<th>MOBILE NUMBER</th>
<th>SEMESTER</th>
<th id="op">OPERATION</th>
</tr>
<td><td><td>
</div>

<?php
$conn = mysqli_connect("localhost", "root", "", "sfeedback");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT name,roll,email,mobileno,sem FROM student";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr>
<td>" . $row["name"]. "</td>
<td>" . $row["roll"] . "</td>
<td>". $row["email"]. "</td>
<td>". $row["mobileno"]."</td>
<td>". $row["sem"] .  "</td>
<td><a href='sdelete.php?rn=$row[roll]'>Delete</td><td> </td>

</tr>" ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>