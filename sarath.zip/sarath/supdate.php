<?php
include("dstu.php")


$rn=$_GET['rn'];
$na=$_GET['na'];
$em=$_GET['em'];
$mo=$_GET['mo'];
$se=$_GET['se'];
?>


<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="adminstyle.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  
  padding: 16px;
  background-color: #C0C0C0;
}

/* Full-width input fields */
input[type=number], input[type=password],input[type=text],input[type=date] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

</style>
</head>
<body>

<form action="" method="GET" > 


<div class="topnav" id="myTopnav">
  <a href="facdashboard.html" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="dstu.php">Manage Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 
</div>

  <div class="container">
    <h1>UPDATE THE DETAILS</h1>
    <p>Please fill in this form to update an account.</p>
    <hr>

    <label ><b> Name</b></label>
    <input type="text" placeholder="Enter your name"  value="<?php echo "$name" ?>"  name="name"  >

    <label ><b>Roll number</b></label>
    <input type="number" name="roll" placeholder="Enter roll number" value="<?php echo "$roll" ?>" >

    <label ><b>Date of Birth</b></label>
    <input type="date" name="dob" placeholder="Enter  date of Birth" value="<?php echo "$dob" ?>" >

     <label ><b>Email</b></label>
    <input type="text" name="email" placeholder="Enter  email"  value="<?php echo "$email" ?>"  >

    <label ><b>Mobile number</b></label>
    <input type="number" placeholder="Enter mobile number" name="mobileno" value="<?php echo "$mobileno" ?>"  >

    <label ><b>Semester</b></label>
    <input type="number" placeholder="Enter semester" name="sem" value="<?php echo "$sem" ?>" >


    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <button type="submit" class="registerbtn" value="Register">update</button>
  </div>
  
</form>


</body>
</html>
