<?php
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
$result = mysqli_query($con,"SELECT * FROM student");
?>


<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" type="text/css" href="adminstyle.css">
    <link rel="stylesheet" type="text/css" href="deluplink.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<div class="topnav" id="myTopnav">
  <a href="facdashboard.php" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="update.php">Edit Students</a>
   <a href="delstu.php">Delete Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 </div>

<table>
<div class="container">	
<tr>
<th>S.NO</th>
<th>ROLL NUMBER</th>
<th>NAME</th>
<th>EMAIL</th>
<th>DATE OF BIRTH</th>
<th>MOBILE NUMBER</th>
<th>SEMESTER</th>
<th>DEPARTMENT</th>
<th id="op">OPERATION</th>
</tr>
<td><td><td>
</div>
			<?php
			$i=0;
			while($row = mysqli_fetch_array($result)) {
			?>
      
	  <tr>
       <td id="cen"><?php echo $row["id"]; ?></td>
	    <td id="cen"><?php echo $row["roll"]; ?></td>
		<td ><?php echo $row["name"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["dob"]; ?></td>
    <td><?php echo $row["mobileno"]; ?>
    </td id="cent"><td><?php echo $row["sem"]; ?></td>
    <td><?php echo $row["dept"]; ?>
		
		<td><a id="edit" href="update-process.php?id=<?php echo $row["id"]; ?>">Edit</a></td>
      </tr>


			<?php
			$i++;
			}
			?>

 <?php
}
else
{
    echo "No result found";
}
?>
 </body>
</html>