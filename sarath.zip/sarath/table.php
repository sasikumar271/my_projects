<!DOCTYPE html>
<html>

<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<style>
  h2{
  font-size: 30px;
  text-align: center;
  color: #D2691E;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin:40px;

}
/* input[type="submit"]
{
  font-family: arial, sans-serif;
   position: absolute;
    bottom: 0%;
    left: 90%;
    top: 55%;
    margin-left: -104.5px;
    border: none;
    outline: none;
    height: 40px;
    background: #48D1CC;
    color: black;
    font-size: 20px;
    border-radius: 10px;

}*/


#t1 th {
  width: 100%;    
  background-color: #48D1CC;
}

.date {
  padding-left: 78%;
  padding-top: 3%;
   border-bottom: 5px #2E8B57;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  background-color:#E0FFFF ;
   padding: 15px;
}
p{
    color: #2E8B57;
    margin: 0;
    padding-left:40% ;
    font-weight: bold;
}
 input[type="number"], input[type="date"],input[type="password"], input[type="text"]
{
    border: none;
    border-bottom: 5px #2E8B57;
    background: transparent;
    outline: none;
    height: 40px;
    color: black;
    font-size: 16px;
    padding-right: 1%; 
    padding-bottom: 3%;

}

input[type="checkbox"]{
	margin-left: 30%;
  cursor: pointer;
}

input[type="submit"]
{
    border: none;
    outline: none;
    width: 250%;
    margin-left: 310%;
    margin-top: 50%;
    height: 40px;
    background:  #48D1CC;
    color: black;
     cursor: pointer;
    font-size: 18px;
    font-weight: bold;
    border-radius: 5px;


}
input[type="button"]
{
    border: none;
     font-weight: bold;
      border-radius: 5px;
    outline: none;
    margin-top: 7%;
    width: 28%;
    height: 40px;
    background:  #48D1CC;
    color: black;
     cursor: pointer;
    font-size: 18px;
   
}

.txt {
	 font-family: sans-serif;
	 
	 font-size: 20px;
}
td.sb{
  border:none;
  text-align: left;
 background-color: white;
   padding: 15px;
}
td.sb1{
  border:none;
  text-align: left;
 background-color: white;
   padding: 15px;
}
</style>
</head>
<body>
	<form action="feedback.php" method="post" > 
  <h2> Please Answer All the Questions Belowing </h2>
  <div class="txt">
  	        <p>Rollnumber:
            <input type="number" name="rollno" placeholder="Enter rollnumber" required="">
            <p>Name:
            <input type="text" name="name" placeholder="Enter name" required="">
             <p>Department:
            <input type="text" name="dept" placeholder="Enter department ex:CSE " required="">
            <p>Year:
            <input type="number" name="year" placeholder="Enter year ex:3" required="">
            <p>Date:
            <input type="date" name="date" placeholder="Enter year ex:3" required="">

  </div>

<table>

  <tr id="t1">
    <th>Questions</th>
    <th>Exelent(5)</th>
    <th>Very good(4)</th>
    <th>Good(3)</th>
    <th>Better(2)</th>
    <th>Poor(1)</th>
  </tr>
    <tr>
    
    <td>How well do the professors teach at this class?</td>
    <td><input type="checkbox" id="radio" name="q1" value='5'></td>
    <td><input type="checkbox" id="radio" name="q1" value='4'></td>
    <td><input type="checkbox" id="radio" name="q1" value='3'></td>
    <td><input type="checkbox" id="radio" name="q1" value='2'></td>
    <td><input type="checkbox" id="radio" name="q1" value='1'></td>

    
  </tr>
  <tr>
  <td>How much value are you getting from this class content overall?</td>
    <td><input type="checkbox" id="chbox2" name="q2" value='5'></td>
    <td><input type="checkbox" id="chbox2" name="q2" value='4'></td>
    <td><input type="checkbox" id="chbox2" name="q2" value='3'></td>
    <td><input type="checkbox" id="chbox2" name="q2" value='2'></td>
    <td><input type="checkbox" id="chbox2" name="q2" value='1'></td>
   
  </tr>
  <tr>
    <td>How safe do you feel on this class?</td>
    <td><input type="checkbox" id="chbox3" name="q3" value='5'></td>
    <td><input type="checkbox" id="chbox3" name="q3" value='4'></td>
    <td><input type="checkbox" id="chbox3" name="q3" value='3'></td>
    <td><input type="checkbox" id="chbox3" name="q3" value='2'></td>
    <td><input type="checkbox" id="chbox3" name="q3" value='1'></td>
    
  </tr>
  <tr>
    <td>How easy it is to get the resources you need from the faculty?</td>
    <td><input type="checkbox" id="chbox4" name="q4" value='5'></td>
    <td><input type="checkbox" id="chbox4" name="q4" value='4'></td>
    <td><input type="checkbox" id="chbox4" name="q4" value='3'></td>
    <td><input type="checkbox" id="chbox4" name="q4" value='2'></td>
    <td><input type="checkbox" id="chbox4" name="q4" value='1'></td>
   
  </tr>
  <tr>
    <td>Does your teacher encourage you to perform better?</td>
    <td><input type="checkbox" id="chbox5" name="q5" value='5'></td>
    <td><input type="checkbox" id="chbox5" name="q5" value='4'></td>
    <td><input type="checkbox" id="chbox5" name="q5" value='3'></td>
    <td><input type="checkbox" id="chbox5" name="q5" value='2'></td>
    <td><input type="checkbox" id="chbox5" name="q5" value='1'></td>
    
  </tr>
  <tr>
    <td>After each test, does your teacher help you in understanding ways to improve your grades?</td>
    <td><input type="checkbox" id="chbox6" name="q6" value='5'></td>
    <td><input type="checkbox" id="chbox6" name="q6" value='4'></td>
    <td><input type="checkbox" id="chbox6" name="q6" value='3'></td>
    <td><input type="checkbox" id="chbox6" name="q6" value='2'></td>
    <td><input type="checkbox" id="chbox6" name="q6" value='1'></td>
   
  </tr>
  
  <tr>
  </br></br>
    <td class="sb1"> <a href="index.html"><input type="button"  value="logout"  name="logout"> </a>  </td>
  	
  	<td class="sb"><input type="submit"   value="submit" name="submit"></td>
</tr>
<div>


  <script type="text/javascript">
    $("input:checkbox").on('click', function() {
  var $box = $(this);
  if ($box.is(":checked")) {
    var group = "input:checkbox[name='" + $box.attr("name") + "']";
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});
  </script>
 
  
  
</table>
</form>

</body>
</html>
