<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="adminstyle.css">
  <link rel="stylesheet" type="text/css" href="deluplink.css">
<title>Table with database</title>
</head>
<body>


<div class="topnav" id="myTopnav">
  <a href="facdashboard.php" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="update.php">Edit Students</a>
   <a href="delstu.php">Delete Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 </div>

<table>
<div class="container">	
<tr>
  <th>S.NO</th>
<th>NAME</th>
<th>ROLL NUMBER</th>
<th>EMAIL</th>
<th>MOBILE NUMBER</th>
<th>SEMESTER</th>
<th>DEPARTMENRT</th>
<th id="op">OPERATION</th>
</tr>
<td><td><td>
</div>

<?php
$conn = mysqli_connect("localhost", "root", "", "sfeedback");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id,name,roll,email,mobileno,sem,dept FROM student";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr>
<td>" . $row["id"]. "</td>
<td>" . $row["name"]. "</td>
<td>" . $row["roll"] . "</td>
<td>". $row["email"]. "</td>
<td>". $row["mobileno"]."</td>
<td>". $row["sem"] .  "</td>
<td>". $row["dept"] .  "</td>
<td><a href='sdelete.php?rn=$row[roll]'>Delete</td><td> </td>

</tr>" ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>