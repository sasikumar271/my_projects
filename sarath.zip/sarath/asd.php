 <?php
 $roll = $_GET['roll'];
 $con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}


 $query = "SELECT * from student where roll = '{$stmt['login_roll']}'";
    $result = mysqli_query($con,$query);
    while($row=mysqli_fetch_assoc($result))
    {
        echo"<tr>";
        echo"<td>";?> <?php echo $row['roll']; ?>  <?php echo "</td>";

        echo"</tr>";
    }
    echo"</table>";
    ?>