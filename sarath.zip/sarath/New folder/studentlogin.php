<!DOCTYPE html>
<head>
<title>Login Form Design</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
body {
  background-image: url('back6.jpg');
}
</style>
    </head>
    

<body>


    <div class="box">

    <img src="s.png" class="user">

        <h1> Student Login</h1>

        <form action="" method="post" >

            <p>Rollnumber</p>
            <input type="number" name="roll" placeholder="Enter rollnumber" required="">

            <p>Date of birth</p>
            <input type="date" name="dob" placeholder="Enter your DOB" required=""><br></br>


            <input type="submit"  value="login" name="login">  
            <br><br>
            <a href="staff.html">I am faculty?</a><br><br>
             <a href="admin.html">I am Admin?</a>
              </form>
        
    </div>
             <?php

$roll = $_POST['roll'];
$dob  = $_POST['dob'];
// Create connection
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
else{
 
//Prepare statement
     $stmt = $con->prepare("select * from student where roll = ?");
     $stmt->bind_param("i", $roll);
     $stmt->execute();
     $stm_result = $stmt->get_result();
     if($stm_result->num_rows > 0)
     {
      $data = $stm_result->fetch_assoc();
      if($data['dob'] === $dob) {
        
        header('location:table.html');
      }else {
        echo "<h2>invalid rollnumber and Date of birth</h2>";

      }
  }

    }else {
      echo "<h2>Acces denied</h2>";
     }
}


     ?>   
</body>
</html>