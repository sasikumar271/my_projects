<style>
  *{
    margin: 0;
    padding: 0;
    font-family: 'Roboto', sans-serif;
}
 h2{
  margin-top: 5%;
  text-align: center;
  margin-bottom: 3%;
  font-size: 28px;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin:40px;

}
/* input[type="submit"]
{
  font-family: arial, sans-serif;
   position: absolute;
    bottom: 0%;
    left: 90%;
    top: 55%;
    margin-left: -104.5px;
    border: none;
    outline: none;
    height: 40px;
    background: #48D1CC;
    color: black;
    font-size: 20px;
    border-radius: 10px;

}*/


#t1 th {
  width: 100%;    
  background-color: #48D1CC;
}

.date {
  padding-left: 78%;
  padding-top: 3%;
   border-bottom: 5px #2E8B57;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  background-color:#E0FFFF ;
   padding: 15px;
}
p{
    color: #2E8B57;
    margin: 0;
    padding-left:40% ;
    font-weight: bold;
}
 input[type="number"], input[type="date"],input[type="password"], input[type="text"]
{
    border: none;
    border-bottom: 5px #2E8B57;
    background: transparent;
    outline: none;
    height: 40px;
    color: black;
    font-size: 16px;
    padding-right: 1%; 
    padding-bottom: 3%;

}

input[type="checkbox"]{
	margin-left: 30%;
  cursor: pointer;
}

input[type="submit"]
{
    border: none;
    outline: none;
    width: 250%;
    margin-left: 310%;
    margin-top: 50%;
    height: 40px;
    background:  #48D1CC;
    color: black;
     cursor: pointer;
    font-size: 18px;
    font-weight: bold;
    border-radius: 5px;


}
input[type="button"]
{
    border: none;
     font-weight: bold;
      border-radius: 5px;
    outline: none;
    margin-top: 7%;
    width: 28%;
    height: 40px;
    background:  #48D1CC;
    color: black;
     cursor: pointer;
    font-size: 18px;
   
}

.txt {
	 font-family: sans-serif;
	 
	 font-size: 20px;
}
td.sb{
  border:none;
  text-align: left;
 background-color: white;
   padding: 15px;
}
td.sb1{
  border:none;
  text-align: left;
 background-color: white;
   padding: 15px;
}