<?php
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
$result = mysqli_query($con,"SELECT * FROM student");
?>


<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" type="text/css" href="adminstyle.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  
  padding: 16px;
  background-color: #C0C0C0;
}

/* Full-width input fields */
input[type=number], input[type=password],input[type=text],input[type=date] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

</style>
</head>
<body>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<div class="topnav" id="myTopnav">
  <a href="facdashboard.html" >Dashboard</a>
  <a href="addstu.html">Add Students</a>
  <a href="dstu.php">Manage Students</a>
  <a href="dfeed.php">View Feedback</a>
  <a href="index.html">Logout</a>
 </div>

<table>
<div class="container">	
<tr>
<th>S.NO</th>
<th>ROLL NUMBER</th>
<th>NAME</th>
<th>EMAIL</th>
<th>MOBILE NUMBER</th>
<th>SEMESTER</th>
<th id="op">OPERATION</th>
</tr>
<td><td><td>
</div>



			<?php
			$i=0;
			while($row = mysqli_fetch_array($result)) {
			?>
	  <tr>
       <td><?php echo $row["id"]; ?></td>
	    <td><?php echo $row["roll"]; ?></td>
		<td><?php echo $row["name"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["mobileno"]; ?>
    </td><td><?php echo $row["sem"]; ?></td>
		
		<td><a href="uppro.php?id=<?php echo $row["id"]; ?>">Update</a></td>
    
      </tr>
			<?php
			$i++;
			}
			?>
</table>
 <?php
}
else
{
    echo "No result found";
}
?>
 </body>
</html>