<?php 
//all complaints
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
$qq=mysqli_query($con,"select * from staff ");
$rows=mysqli_num_rows($qq);			
echo "<h2 style='color:green'>Total Number of Faculty : $rows</h2>";	

//all emegency compalints
$q=mysqli_query($con,"select * from student");
$r1=mysqli_num_rows($q);			
echo "<h2 style='color:orange'>Total Number of Student : $r1</h2>";	


//all users
$q2=mysqli_query($con,"select * from feedback");
$r2=mysqli_num_rows($q2);			
echo "<h2 style='color:black'>Total Number feedback given by users  : $r2</h2>";	
	

?>

<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" type="text/css" href="adminstyle.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>



<div class="topnav" id="myTopnav">
  <a href="admindashboard.html" >Dashboard</a>
  <a href="aaddfac.html">Add faculty</a>
  <a href="dfac.php">Manage Faculty</a>
  <a href="index.html">Logout</a>

</div>

</body>
</html>
