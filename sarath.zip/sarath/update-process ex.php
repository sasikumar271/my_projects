<?php


$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}

if(count($_POST)>0) {
mysqli_query($con,"UPDATE student set id='" . $_POST['id'] . "', roll='" . $_POST['roll'] . "', name='" . $_POST['name'] . "', email='" . $_POST['email'] . "', mobileno='" . $_POST['mobileno'] . "' ,sem='" . $_POST['sem'] . "' WHERE id='" . $_POST['id'] . "'");
$message = "Record Modified Successfully";
}






$result = mysqli_query($con,"SELECT * FROM student WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<title>Update Employee Data</title>
</head>
<body>
<form name="frmUser" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<div style="padding-bottom:5px;">
<a href="retrieve.php">Employee List</a>
</div>
sno: <br>
<input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
<input type="number" name="id"  value="<?php echo $row['id']; ?>">
<br>
 roll: <br>
<input type="number" name="roll" class="txtField" value="<?php echo $row['roll']; ?>">
<br>
 Name: <br>
<input type="text" name="name" class="txtField" value="<?php echo $row['name']; ?>">
<br>
mobile:<br>
<input type="number" name="mobileno" class="txtField" value="<?php echo $row['mobileno']; ?>">
<br>
email :<br>
<input type="text" name="email" class="txtField" value="<?php echo $row['email']; ?>">
<br>

date:<br>
<input type="dob" name="dob" class="txtField" value="<?php echo $row['dob']; ?>">
<br>
sem:<br>
<input type="number" name="sem" class="txtField" value="<?php echo $row['sem']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">

</form>
</body>
</html>