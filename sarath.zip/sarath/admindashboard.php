<?php 
//all complaints
$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}
$qq=mysqli_query($con,"select * from staff ");
$rows=mysqli_num_rows($qq);     

 $q=mysqli_query($con,"select * from student");
$r1=mysqli_num_rows($q);      
//all users
$q2=mysqli_query($con,"select * from feedback");
$r2=mysqli_num_rows($q2);     
  
?>
<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" type="text/css" href="adminstyle.css">
      <link rel="stylesheet" type="text/css" href="dash.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="topnav" id="myTopnav">
  <a href="admindashboard.php" >Dashboard</a>
  <a href="aaddfac.html">Add faculty</a>
  <a href="dfac.php">Edit Faculty</a>
  <a href="dtu.php">Delete Faculty</a>
  <a href="index.html">Logout</a>
 </div>
  
  </a>
</div>
<div class="box">
  <img src="s.png" class="user"><button class="b1"> No.Faculty <div id="b1"><?php   echo"$rows"?> <br></div></button>
  <img src="t.png" class="user1"><button class="b2"> No.Students <div id="b2"><?php   echo"$r1"?><br></div></button>
   <img src="fd.png" class="user2"> <button class="b3"> No.Feedback      <div id="b3"><?php   echo"$r2"?><br></div></button>

  
  
</div>


</body>
</html>
