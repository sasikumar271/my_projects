<?php
$conn = mysqli_connect("localhost", "root", "", "sfeedback");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}