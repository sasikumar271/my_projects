<?php


$con = new mysqli ("localhost","root","","sfeedback");
if($con->connect_error) {
  die("Connect Error : ".$con->connect_error); 
}

if(count($_POST)>0) {
mysqli_query($con,"UPDATE staff set id='" . $_POST['id'] . "', staffid='" . $_POST['staffid'] . "', name='" . $_POST['name'] . "', dept='" . $_POST['dept'] . "',spswd='" . $_POST['spswd'] . "',mobileno='" . $_POST['mobileno'] . "'  WHERE id='" . $_POST['id'] . "'");
$message = "Record Modified Successfully";
}
$result = mysqli_query($con,"SELECT * FROM staff WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>



<html>
<head>
<title>Update Employee Data</title>
<link rel="stylesheet" type="text/css" href="adminstyle.css">
<link rel="stylesheet" type="text/css" href="register.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>



<form  method="post" action="">
<div>

	<?php if(isset($message)) {
  echo "<h1>Record Modified Successfully!!</h1>";
    } ?>
</div>
<div class="topnav" id="myTopnav">
  <a href="admindashboard.php" >Dashboard</a>
  <a href="aaddfac.html">Add faculty</a>
  <a href="dfac.php">Edit Faculty</a>
  <a href="dtu.php">Delete Faculty</a>
  <a href="index.html">Logout</a>
 </div>
  <div class="container">
    
    <hr>
    <label ><b>s.no</b></label>
    <input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
    <input type="number" name="id"  value="<?php echo $row['id']; ?>">

    <label ><b>Staff id</b></label>
   <input type="number" name="staffid" class="txtField" value="<?php echo $row['staffid']; ?>">

    <label ><b> Name</b></label>
    <input type="text" name="name" class="txtField" value="<?php echo $row['name']; ?>">
    

     <label ><b>Department</b></label>
    <input type="text" name="dept" class="txtField" value="<?php echo $row['dept']; ?>">

     <label ><b>spswd</b></label>
    <input type="text" name="spswd" class="txtField" value="<?php echo $row['spswd']; ?>">

    <label ><b>Mobile number</b></label>
    <input type="number" name="mobileno" class="txtField" value="<?php echo $row['mobileno']; ?>">




    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <input type="submit" name="submit" value="Submit" class="registerbtn">
  </div>
  </form>
</body>
</html>
  






