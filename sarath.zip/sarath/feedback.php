<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style >
        body{
            background-color: #E6E6FA;
        }
    .txt{
        font-size: 20px;
    }
  a:link, a:visited {
  background-color: #32A852;
  color: white;
  margin-left: 40%;
 margin-top: 15%;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-radius: 10px;
}

a:hover, a:active {
  background-color: red;
}
h2{
    padding-left: 38%;
}
</style>

</head>
<body>
<div class="txt">
<a href="tablemain.html">GO BACK</a>
</div>

<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "sfeedback");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
     $name = mysqli_real_escape_string($link, $_REQUEST['name']);
     $rollno = mysqli_real_escape_string($link, $_REQUEST['rollno']);
     $year = mysqli_real_escape_string($link, $_REQUEST['year']);
     $dept = mysqli_real_escape_string($link, $_REQUEST['dept']);
     $q1 = mysqli_real_escape_string($link, $_REQUEST['q1']);
     $q2 = mysqli_real_escape_string($link, $_REQUEST['q2']);
     $q3 = mysqli_real_escape_string($link, $_REQUEST['q3']);
     $q4 = mysqli_real_escape_string($link, $_REQUEST['q4']);
     $q5 = mysqli_real_escape_string($link, $_REQUEST['q5']);
     $q6 = mysqli_real_escape_string($link, $_REQUEST['q6']);
     $date = mysqli_real_escape_string($link, $_REQUEST['date']);
     
    
// Attempt insert query execution
$sql = "INSERT INTO feedback (name,rollno,year,dept,q1,q2,q3,q4,q5,q6,date)  VALUES ('$name','$rollno','$year','$dept','$q1','$q2','$q3','$q4','$q5','$q6','$date')";
if(mysqli_query($link, $sql)){
    echo "<h2> submitted  successfull!!<h2>";
} else{
  echo "<h2> Your Aldready submitted!!<h2>";
}
// Close connection
mysqli_close($link);
?>
</body>
</html>